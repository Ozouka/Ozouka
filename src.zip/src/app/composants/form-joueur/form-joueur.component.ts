import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Joueur } from 'src/app/models/joueur';
import { Partie } from 'src/app/models/partie';
import { DonneesService } from 'src/app/services/donnees.service';

@Component({
  selector: 'app-form-joueur',
  templateUrl: './form-joueur.component.html',
  styleUrls: ['./form-joueur.component.css'],
})
export class FormJoueurComponent {
  constructor(private partieService: DonneesService, private routeur: Router) {}

  public onSubmit(leFormulaire: NgForm): void {
    if (leFormulaire.valid) {
      const listJoueur = [
        new Joueur(1, leFormulaire.value.j1),
        new Joueur(2, leFormulaire.value.j2),
        new Joueur(3, leFormulaire.value.j3),
        new Joueur(4, leFormulaire.value.j4),
      ];
      const objet = new Partie(0, listJoueur, [0, 0, 0, 0], []);
      this.partieService.addPartie(objet);
      this.routeur.navigateByUrl('composants/partie/' + objet.id);
    }
  }
}
