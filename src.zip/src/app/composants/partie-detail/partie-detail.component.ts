import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Partie } from 'src/app/models/partie';
import { DonneesService } from 'src/app/services/donnees.service';

@Component({
  selector: 'app-partie-detail',
  templateUrl: './partie-detail.component.html',
  styleUrls: ['./partie-detail.component.css'],
})
export class PartieDetailComponent {
  public partie = new Partie();

  constructor(
    private partieService: DonneesService,
    private routeur: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.params['id'];
    const partie = this.partieService.getPartie(id);
    if (partie === undefined || partie == null) {
      this.routeur.navigateByUrl('');
    } else {
      this.partie = partie;
    }
  }
}
