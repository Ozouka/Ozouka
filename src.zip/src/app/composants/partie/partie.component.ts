import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Manche } from 'src/app/models/manche';
import { Partie } from 'src/app/models/partie';
import { DonneesService } from 'src/app/services/donnees.service';

@Component({
  selector: 'app-partie',
  templateUrl: './partie.component.html',
  styleUrls: ['./partie.component.css'],
})
export class PartieComponent {
  public partie: Partie = new Partie();
  public manche: Manche = new Manche();

  constructor(
    private partieService: DonneesService,
    private routeur: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    const idPartie = this.route.snapshot.params['id'];
    if (idPartie === undefined) {
    } else {
      const partie = this.partieService.getPartie(idPartie);
      if (partie === undefined || partie.listeManches.length != 0) {
        this.routeur.navigateByUrl('');
      } else {
        this.partie = partie;
      }
    }
  }

  public saveGame(leFormulaire: NgForm): void {
    if (leFormulaire.valid) {
      this.onSubmit(leFormulaire);
      this.routeur.navigateByUrl('');
    }
  }

  public onSubmit(leFormulaire: NgForm): void {
    if (leFormulaire.valid) {
      const manche = new Manche(0, [0, 0, 0, 0]);
      const scoreManche = this.pointrealiser(leFormulaire);
      const idAttaquant = leFormulaire.value.joueurPreneur;
      const listCoef = this.setCoef(leFormulaire.value.res);
      this.partieService.addManche(
        this.partie,
        manche,
        scoreManche,
        idAttaquant,
        listCoef
      );
      leFormulaire.reset();
    }
  }

  public pointrealiser(leFormulaire: NgForm): number {
    let nombre: number = 25;
    const bonus = this.pab(leFormulaire.value.pab);
    if (leFormulaire.value.bouts == '0') {
      nombre += Math.abs(leFormulaire.value.points - 56);
    } else if (leFormulaire.value.bouts == '1') {
      nombre += Math.abs(leFormulaire.value.points - 51);
    } else if (leFormulaire.value.bouts == '2') {
      nombre += Math.abs(leFormulaire.value.points - 41);
    } else if (leFormulaire.value.bouts == '3') {
      nombre += Math.abs(leFormulaire.value.points - 36);
    }
    nombre += bonus;
    nombre *= this.getCoef(leFormulaire.value.contrat);
    nombre += this.getPoignee(leFormulaire.value.poignee);
    return nombre;
  }

  public getPoignee(poignee: string): number {
    switch (poignee) {
      case 'simple':
        return 20;
      case 'double':
        return 30;
      case 'triple':
        return 40;
      default:
        return 0;
    }
  }

  public getCoef(contrat: string): number {
    switch (contrat) {
      case 'petite':
        return 1;
      case 'garde':
        return 2;
      case 'gardeSans':
        return 4;
      case 'gardeContre':
        return 6;
      default:
        return 0;
    }
  }

  public setCoef(win: string): number[] {
    const listCoef = new Array<number>(2);
    if (win == 'true') {
      listCoef[0] = 3;
      listCoef[1] = -1;
    } else {
      listCoef[0] = -3;
      listCoef[1] = 1;
    }
    return listCoef;
  }

  public pab(msg: string): number {
    if (msg == 'true') {
      return 10;
    } else {
      return 0;
    }
  }
}
