import { Component } from '@angular/core';
import { Partie } from 'src/app/models/partie';
import { DonneesService } from 'src/app/services/donnees.service';

@Component({
  selector: 'app-historique',
  templateUrl: './historique.component.html',
  styleUrls: ['./historique.component.css'],
})
export class HistoriqueComponent {
  public parties: Partie[] = [];

  constructor(private partieService: DonneesService) {}

  ngOnInit() {
    this.parties = this.partieService.getParties();
  }
}
