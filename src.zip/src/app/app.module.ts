import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccueilComponent } from './composants/accueil/accueil.component';
import { RulesComponent } from './composants/rules/rules.component';
import { HistoriqueComponent } from './composants/historique/historique.component';
import { PartieComponent } from './composants/partie/partie.component';

import { DonneesService } from './services/donnees.service';

import { FormsModule } from '@angular/forms';
import { FormJoueurComponent } from './composants/form-joueur/form-joueur.component';
import { PartieDetailComponent } from './composants/partie-detail/partie-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    AccueilComponent,
    RulesComponent,
    HistoriqueComponent,
    PartieComponent,
    FormJoueurComponent,
    PartieDetailComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, FormsModule],
  providers: [DonneesService],
  bootstrap: [AppComponent],
})
export class AppModule {}
