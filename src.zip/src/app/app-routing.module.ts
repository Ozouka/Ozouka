import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccueilComponent } from './composants/accueil/accueil.component';
import { FormJoueurComponent } from './composants/form-joueur/form-joueur.component';
import { HistoriqueComponent } from './composants/historique/historique.component';
import { PartieDetailComponent } from './composants/partie-detail/partie-detail.component';
import { PartieComponent } from './composants/partie/partie.component';
import { RulesComponent } from './composants/rules/rules.component';

const routes: Routes = [
  { path: '', component: AccueilComponent },
  { path: 'composants/partie/:id', component: PartieComponent },
  { path: 'composants/historique', component: HistoriqueComponent },
  { path: 'composants/rules', component: RulesComponent },
  { path: 'composants/joueur', component: FormJoueurComponent },
  { path: 'composants/historique/game/:id', component: PartieDetailComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
