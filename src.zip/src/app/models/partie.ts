import { Joueur } from './joueur';
import { Manche } from './manche';

export class Partie {
  constructor(
    public id: number = 0,
    public listeJoueur: Joueur[] = new Array<Joueur>(),
    public scoreTotaux: number[] = new Array<number>(),
    public listeManches: Manche[] = new Array<Manche>()
  ) {}
}
