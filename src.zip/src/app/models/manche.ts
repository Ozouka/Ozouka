export class Manche {
  constructor(
    public id: number = 0,
    public listeScore: number[] = new Array<number>()
  ) {}
}
