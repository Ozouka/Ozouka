import { Injectable } from '@angular/core';
import { Manche } from 'src/app/models/manche';
import { Partie } from '../models/partie';

@Injectable({
  providedIn: 'root',
})
export class DonneesService {
  public parties: Partie[] = [];

  constructor() {
    const jsonParties = localStorage.getItem('listeManches');
    if (jsonParties) {
      this.parties = JSON.parse(jsonParties);
    } else {
      this.saveAllParties();
    }
  }

  private saveAllParties(): void {
    localStorage['listeManches'] = JSON.stringify(this.parties);
  }

  addManche(
    partie: Partie,
    nouvelleManche: Manche,
    score: number,
    idAttaquant: number,
    coefList: number[]
  ): Manche {
    const idManche = partie.listeManches.length + 1;
    nouvelleManche.id = idManche;
    for (let index = 0; index < 4; index++) {
      if (index == idAttaquant - 1) {
        nouvelleManche.listeScore[index] = score * coefList[0];
      } else {
        nouvelleManche.listeScore[index] = score * coefList[1];
      }
    }

    partie.listeManches.push(nouvelleManche);

    for (let index = 0; index < 4; index++) {
      partie.scoreTotaux[index] += nouvelleManche.listeScore[index];
    }

    this.saveAllParties();

    return nouvelleManche;
  }

  getParties() {
    return this.parties;
  }

  getPartie(id: number): Partie | undefined {
    return this.parties.find((t) => t.id == id);
  }

  addPartie(nouvellePartie: Partie): Partie {
    const idPartie = this.parties.length + 1;
    nouvellePartie.id = idPartie;
    this.parties.push(nouvellePartie);
    this.saveAllParties();

    return nouvellePartie;
  }
}
